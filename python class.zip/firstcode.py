##z = 20
##
##for i in range(10):
##    
##    q = i * z
##    print("i, q")
##
##    print("done")

# price = 520.30
# qty = input("Please enter the quantity sold > ")

# integer_qty = int(qty) # type casting

# income = integer_qty * price

# print(income)

# cost_price = 400
# price = 520.30

# qty = input("Please enter the quantity sold > ")

# integer_qty = int(qty) # type casting

# expenditure = cost_price * integer_qty
# income = integer_qty * price

# profit = income - expenditure
# print("income -", income)
# print("profit -", profit)


# DATA TYPES AND TYPE CASTING

## INT, FLOAT, BOOLEAN, STRING, COMPLEX

# INTEGER = 20
# STRING = "20"
# BOOLEAN = True
# COMPLEX = 2+1j
# FLOAT = 23.01

# print(type(INTEGER))
# print(type(STRING))
# print(type(BOOLEAN))
# print(type(COMPLEX))
# print(type(FLOAT))
##
##
##age = 20.223
##name = "Ade"
##height = 23.01
##is_raining_outside = True
##equation_result = 2+1j
##
##print()
##
##print("age", type(age))
##print("name", type(name))
##print("height", type(height))
##print("equation_result", type(equation_result))
##print("is_raining_outside", type(is_raining_outside))
##
##print()
##
##print(str(INTEGER))
##print(float(INTEGER))
##print(bool(INTEGER))
##print(complex(INTEGER))

##while True:
##    
##    x = (input("Please enter first number > "))
##    y = (input("Please enter second number > "))
##
##    try ZeroDivisionError:
##        x = int(x)
##        y = int(y)
##        print(x/y)
##
##    except:
##
##        print("Sorry you can't divide by zero")

##filename = "data.csv"
##target_file = open(filename, "w")
##
##print("hello","ada",2, sep = "-", end = "nothing else")
##print("10","05","2020", sep = "-", file = target_file)
##
##target_file.close()

# name = input("Please enter your name : ")
# age = input("Please enter your age : ")
# gender = input("Please enter your gender : ")
# print(name, age, gender)

# filename = "data.csv"
# target_file = open(filename, "a")

# # print("hello","ada",2, sep = "-", end = "nothing else")
# print(name, age, gender, sep = ",", file = target_file)

# target_file.close()

# cost = 500
# sold = 300

# difference_value = sold - cost

# absolute_difference = abs(difference_value)

# print("Difference", difference_value)
# print("Absolute Diff", absolute_difference)

# name  = "Adenuga"

# print(min(name)) # minimum value
# print(max(name)) # maximum value

# scores = [10, 45, 80, 22, 15, 9]

# print(min(scores)) # minimum value
# print(max(scores)) # maximum value

# print(len(scores))
# print(len(name))

# sequence = range(20) # range(qty)
# sequence2 = range(5, 20) # range(start, stop)
# sequence3 = range(5, 20, 3) # range(start, stop, step)

# # print(sequence)
# print(list(sequence))
# print()
# print(list(sequence2))
# print()
# print(list(sequence3))

# SUM BUILTIN METHOD

# print(sum([2,4,6]))
# print(sorted([2,4,1,4,2,444,1], reverse = True))

# text = input("Please enter text : ")

# print(text.upper())
# print(text.lower())
# print(text.strip())

# new_text = text.lower()
# print(new_text.replace("world", "person"))

# text = input("Please enter name, age & sex \nseperated by commas \n: ")
# print(text.split(","))

# name, age, sex = text.split(",")

# print(name, age, sex)

# first_name = input("Please enter first_name : ")
# last_name = input("Please enter last name : ")

# full_name = "-".join([first_name, last_name])

# print(full_name)

# x = 10
# y = 5

# if x > y :

#     name = input("Please enter your name : ")

#     print("Hello", name.capitalize(), ",your name contains", len(name), "characters.")
#     print(f"Hello {name.capitalize()}, your name contains {len(name)} characters.")

# password = "1c3290cvv"

# input_password = input("Please enter password to see secrets ; ")
# personality = input("Please who are you ? ; ")

# if password == input_password or personality == "vip":
#     secret = "all the bad things i've done".capitalize()
#     print(secret)
    

# cost_price = 259000
# total_sales = 3000080
# qty_purchased = 29

# interest = total_sales - cost_prPice
# interest_percent = (interest/cost_price) * 100
# rounded_value = round(interest_percent, 1)
# print(f"{interest_percent}% Interest today")
# print(f"{rounded_value}% 
# Interest today")

