# # import time 

# # minutes = 3
# # seconds = minutes * 60

# # for i in reversed(range(seconds)):
# #     print(int(i/60), i%60, sep=":")
# #     time.sleep(1)

# # for i in reversed(range(minutes)):
# #     for j in reversed(range(60)):
# #         print(i,j, sep = ":")
# #         time.sleep(1)

# # for i in reversed(range(seconds)):
# #     mins, secs = divmod(i, 60)
# #     print(mins, secs, sep = ":")
# #     time.sleep(1)

# import time
# import winsound

# minutes = 1

# for i in reversed(range(minutes)):

#     for j in reversed(range(1)):

#         print(i, ":", j)
#         time.sleep(1)

# winsound.Beep(500, 1000) # FREQUENCY/ PITCH , DURATION IN miliSECONDS


