# class Student():

#     #Class attributes
#     attendance = 0
#     uniform = True
#     school_fees = "unpaid"

# class Proper_Student(Student):

#     def __init__(self, name, age, course):

#         self.name = name
#         self.age = age
#         self.course = course


# # ayodele = Student()
# # funke = Student()

# # print(ayodele.attendance)
# # print(ayodele.uniform)
# # print(ayodele.school_fees)
# # # print(ayodele.name)

# # print(funke.attendance)
# # print(funke.uniform)
# # print(funke.school_fees)

# ali = Proper_Student(name = "Ali miohammed", age = 28, course = "Maths")

# print(ali.attendance)
# print(ali.uniform)
# print(ali.school_fees)
# ali.school_fees = "paid"
# print(ali.name)
# print(ali.school_fees)