# my_data = {"key":"value"}
# my_data

# print(my_data)

# my_data = {"key":"value"}


# print(my_data["key"])

class_studs = {"atha":"Atha boss", "atha":"Atha boss", "ezra":"Ezra chairman", "halimah":"Boss geh Halimah"}

# print(class_studs["atha"])

# adding to a diction--*-*6-*-/ ary

class_studs["tobi"] = "Honorable bossest"

print(class_studs)